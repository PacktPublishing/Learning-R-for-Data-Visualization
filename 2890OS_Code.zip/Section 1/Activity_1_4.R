#Set the working directory where the dataset is stored
setwd("E:/OneDrive/R Video Course - Packt/Data")


#Loading CSV Files
Data <- read.table(file="EPA_Data.csv", 
                   sep=",", 
                   header=TRUE, 
                   colClasses=c("Date","factor",rep("numeric",5)), 
                   na.string="NA")

help(read.table)

#Examining the data
str(Data)
